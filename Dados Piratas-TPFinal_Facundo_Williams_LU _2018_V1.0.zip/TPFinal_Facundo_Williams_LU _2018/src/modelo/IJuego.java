package modelo;

import java.rmi.RemoteException;
import java.util.ArrayList;

import ar.edu.unlu.rmimvc.observer.IObservableRemoto;
import modelo.Juego.ESTADO;

public interface IJuego extends IObservableRemoto {
	


	/* (non-Javadoc)
	 * @see modelo.IControladorRemoto#agregarJugador(java.lang.String)
	 */
	void agregarJugador(String nombre) throws RemoteException;

	/* (non-Javadoc)
	 * @see modelo.IControladorRemoto#definirCantDados(int)
	 */
	void definirCantDados(int numeroDeDados) throws IllegalArgumentException, RemoteException;

	/* (non-Javadoc)
	 * @see modelo.IControladorRemoto#finalizarPartida()
	 */
	void finalizarPartida() throws RemoteException;

	/* (non-Javadoc)
	 * @see modelo.IControladorRemoto#iniciarPartida()
	 */
	void iniciarPartida() throws Exception, RemoteException;

	/* (non-Javadoc)
	 * @see modelo.IControladorRemoto#getJugadorEnTurno()
	 */
	IJugador getJugadorEnTurno() throws Exception, RemoteException;

	/* (non-Javadoc)
	 * @see modelo.IControladorRemoto#tirarDados()
	 */
	void tirarDados() throws RemoteException;

	/* (non-Javadoc)
	 * @see modelo.IControladorRemoto#verificarProposicion(int, int)
	 */
	boolean verificarProposicion(int cantidadDeDados, int valorDeCara) throws RemoteException;

	/* (non-Javadoc)
	 * @see modelo.IControladorRemoto#desconfiar(modelo.IJugador, modelo.IJugador)
	 */
	void desconfiar() throws Exception, RemoteException;

	/* (non-Javadoc)
	 * @see modelo.IControladorRemoto#subirApuesta(int, int)
	 */
	void subirApuesta(int cantDados, int valorDados) throws RemoteException;

	/* (non-Javadoc)
	 * @see modelo.IControladorRemoto#apuestaSegura(int, int)
	 */
	void apuestaSegura(int apuestaCantDados, int apuestaValorDados) throws RemoteException;

	/* (non-Javadoc)
	 * @see modelo.IControladorRemoto#getEstado()
	 */
	ESTADO getEstado() throws RemoteException;

	/* (non-Javadoc)
	 * @see modelo.IControladorRemoto#definirCantCaras(java.lang.Integer)
	 */
	void definirCantCaras(Integer valueOf) throws RemoteException,IllegalArgumentException;

	/* (non-Javadoc)
	 * @see modelo.IControladorRemoto#getUltimoJugadorPropuso()
	 */
	IJugador getUltimoJugadorPropuso() throws RemoteException;

	/* (non-Javadoc)
	 * @see modelo.IControladorRemoto#getGanador()
	 */
	IJugador getGanador() throws Exception, RemoteException;

	/* (non-Javadoc)
	 * @see modelo.IControladorRemoto#iniciarJuego()
	 */
	void iniciarJuego() throws RemoteException;

	/* (non-Javadoc)
	 * @see modelo.IControladorRemoto#getJugadores()
	 */
	ArrayList<IJugador> getJugadores() throws RemoteException;

	/* (non-Javadoc)
	 * @see modelo.IControladorRemoto#getUltimaProposicionCant()
	 */
	int getUltimaProposicionCant() throws RemoteException;

	/* (non-Javadoc)
	 * @see modelo.IControladorRemoto#getUltimaProposicionValor()
	 */
	int getUltimaProposicionValor() throws RemoteException;

	/* (non-Javadoc)
	 * @see modelo.IControladorRemoto#getTurno()
	 */
	int getTurno() throws RemoteException;

	/* (non-Javadoc)
	 * @see modelo.IControladorRemoto#cambiarTurno()
	 */
	void cambiarTurno() throws RemoteException;

	/* (non-Javadoc)
	 * @see modelo.IControladorRemoto#rendirse()
	 */
	void rendirse() throws RemoteException;

	/* (non-Javadoc)
		 * @see modelo.IControladorRemoto#getTodosLosDados()
		 */
	int[] getTodosLosDados() throws RemoteException//devuelvo un cubilete con TODOS los dados en juego
	;

	/* (non-Javadoc)
	 * @see modelo.IControladorRemoto#getRonda()
	 */
	int getRonda() throws RemoteException;

	/* (non-Javadoc)
	 * @see modelo.IControladorRemoto#getInstrucciones()
	 */
	String getInstrucciones() throws RemoteException;

	/* (non-Javadoc)
	 * @see modelo.IControladorRemoto#validarCara(java.lang.Integer)
	 */
	boolean validarCara(Integer valueOf) throws RemoteException;

	/* (non-Javadoc)
	 * @see modelo.IControladorRemoto#validarCantDados(int)
	 */
	boolean validarCantDados(int valueOf) throws RemoteException;

	int getCantCaras() throws RemoteException;

	int getCantDadosTodos() throws RemoteException;

	int getCantJugadores()throws RemoteException;

	int getNroJugadorEnTurno()throws RemoteException;

	void guardarGanador() throws RemoteException;

	ArrayList<String> getListaGanadores()throws RemoteException;


}