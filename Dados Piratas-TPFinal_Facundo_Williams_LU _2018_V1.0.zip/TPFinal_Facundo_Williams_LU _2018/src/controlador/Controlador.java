package controlador;

import java.rmi.RemoteException;
import java.util.ArrayList;
import ar.edu.unlu.rmimvc.cliente.IControladorRemoto;
import ar.edu.unlu.rmimvc.observer.IObservableRemoto;
import modelo.IJugador;
import modelo.Juego.ESTADO;
import modelo.CambiosModelo;
//import vista.consola.VistaConsola;
import modelo.IJuego;

public class Controlador implements IControladorRemoto{
	private IJuego juego;
	private IVista vista;
	private int miTurno=-1;
	//private Jugador jugadorUsandoControlador; para una  futura funcionalidad de preguntar si todos los jugadores estan listos...

	
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////	
///////////Esta porcion de codigo fue retirada al momento de implementar la libreria rmi (antes habia un solo controlador)////////////////
	
	/*public Controlador(Juego juego, IVista vista) {
		this.juego=juego;
		this.vista=vista;
		/*juego.addObserver(this);
		  NOTA: no hace falta usar el m�todo agregarObservador() del modelo, la libreria agrega al controlador autom�ticamente como observador del modelo.
		vista.setControlador(this);
	}
	public static void main(String[] args) {
		IJuego juego;
		try {
			juego = new Juego();
			juego.iniciarJuego();
		} catch (RemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		//Controlador controlador = new Controlador (juego,vista);
	} 
*/

	public void definirCantMaxDados(Integer valueOf) 
	{
		try {
			juego.definirCantDados(valueOf);
		} catch (IllegalArgumentException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (RemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}		
	}
	public void definirCantMaxCaras(Integer valueOf) {
		try {
			juego.definirCantCaras(valueOf);
		} catch (RemoteException | IllegalArgumentException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	public IJugador getJugadorEnTurno() {
		try {
			return juego.getJugadorEnTurno();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}

	public int getCantDados(IJugador jugadorEnTurno) 
	{
		int cc=-1;
		try {
			cc= jugadorEnTurno.getCantidadDeDados();
		} catch (RemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return cc;
	}
	public void subirApuesta(int apuestaCantDados, int apuestaValorDados) 
	{
		try {
			juego.subirApuesta(apuestaCantDados, apuestaValorDados);
		} catch (RemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	public int [] getValoresDados() throws RemoteException
	{
		int [] resultado = null;
		try {
			resultado = juego.getJugadorEnTurno().getValoresDados();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return resultado;
	}
	public void oponenteMiente() {//TODO cambio, revisar
		try {
			juego.desconfiar();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public IJugador getUltimoJugadorPropuso() throws RemoteException
	{
		return juego.getUltimoJugadorPropuso();
	}
	public void apuestaSegura(int apuestaCantDados, int apuestaValorDados)
	{
		try {
			juego.apuestaSegura(apuestaCantDados, apuestaValorDados);
		} catch (RemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public void iniciarPartida() {
			//if (juego.getJugadores().size()>=2) YA NO ES VALIDO PUES AHORA HAY UN CONTROLADOR PARA CADA JUGADOR
				try {
					juego.iniciarPartida();
				} catch (RemoteException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
	}
	public IJugador getGanador() throws RemoteException, Exception 
	{
		return juego.getGanador();
	}
	public void agregarJugador(String nombre) 
	{
		try {
			juego.agregarJugador(nombre);
			miTurno= juego.getCantJugadores()-1;//-1 pues el primer jugador es el numero 0
		} catch (RemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	public ArrayList<IJugador> getJugadores() throws RemoteException 
	{
		return juego.getJugadores();
	}
	public int getUltimaProposicionCant() throws RemoteException 
	{
		return /*Integer.toString(*/juego.getUltimaProposicionCant();
	}
	public int getUltimaProposicionValor() throws RemoteException 
	{
		return /*Integer.toString(*/ juego.getUltimaProposicionValor() ;
	}
	public boolean primerTurno() throws RemoteException 
	{
		return (juego.getTurno() == 1);
	}
	public void rendirse() 
	{
		try {
			juego.rendirse();
		} catch (RemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}		
	}
	public void configurar() {
		vista.mostrarConfigurando();
		
	}
	public String getInstrucciones() throws RemoteException 
	{

		return juego.getInstrucciones();
	}
	public boolean validarCara(Integer valueOf) throws RemoteException 
	{
		boolean valido=juego.validarCara(valueOf);
		if (valido)
			return true;
		else
		{
			vista.mostrarMensaje("El valor de cara ingresado no es valido!!");
			return false;
		}
	}
	public boolean validarCantDados(Integer valueOf) throws RemoteException
	{
		boolean valido = juego.validarCantDados(valueOf);
		if (!valido)
		{
			vista.mostrarMensaje("Cantidad de dados ingresada no es valida!!");
			return false;
		}
		else
			return true;
	}

	@Override
	public <T extends IObservableRemoto> void setModeloRemoto(T modeloRemoto)  
	{
		this.juego = (IJuego) modeloRemoto;
		
	}
	
	public void setVista(IVista vista) {
		this.vista = vista;
	}

	public int getCantDadosTodos() 
	{
		int i=0;
		try {
			i= juego.getCantDadosTodos();
		} catch (RemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return i;
	}

	public int getCantCaras() 
	{
		int i=0;
		try {
			i = juego.getCantCaras();
		} catch (RemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return i;
	}


	@Override
	public void actualizar(IObservableRemoto arg0, Object arg1) throws RemoteException
	{
		if (arg1 instanceof CambiosModelo) 
		{
			CambiosModelo cambio = (CambiosModelo) arg1;
			switch(cambio) 
			{
			case ESTADO:
				try {
					ESTADO e = juego.getEstado();
					if (e == ESTADO.CONFIGURACION)
						vista.mostrarConfigurando();
					else
						if (e== ESTADO.JUGANDO) {
								vista.mostrarJugando();
						}
						else
							if (e == ESTADO.FINALIZADO)
								vista.mostrarFinDelJuego();
				} catch (RemoteException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				break;
			case COMIENZA_EL_JUEGO:
				vista.mostrarJugando();
				break;
			case TURNO:
				vista.mostrarJugando();
				break;
			case DESCONFIA_PIERDE:
				vista.desconfiaPierde();
				//vista.mostrarTodosLosDados();
				vista.mostrarJugando();
				break;
			case DESCONFIA_GANA:
				vista.desconfiaGana();
				//vista.mostrarTodosLosDados();
				vista.mostrarJugando();
				break;
			case LISTA_JUGADORES:
				vista.mostrarConfigurando();
				break;
			case JUGADOR_GANA:
				vista.mostrarFinDelJuego();
				break;
			case APUESTA_SEGURA_GANA:
					vista.apuestaSeguraGana();
					//vista.mostrarTodosLosDados();
					vista.mostrarJugando();
					break;
			case APUESTA_SEGURA_PIERDE:
				vista.apuestaSeguraPierde();
				//vista.mostrarTodosLosDados();
				vista.mostrarJugando();
				break;
			case APUESTA_INVALIDA:
				vista.mostrarMensaje("Cantidad de dados y valor ingresado no son validos!!");	
				vista.mostrarJugando();
				break;
			default: System.out.println("ESTOY EN EL CASO DEFAULT DEL CONTROLADOR!!"+cambio);
			break;
		
	}
		}
	}
	public boolean esMiTurno() 
	{
		boolean meToca=false;
		try {
			meToca = ( juego.getNroJugadorEnTurno() == miTurno );
		} catch (RemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return meToca;
	}
	public void guardarGanador() 
	{
		try {
			juego.guardarGanador();
		} catch (RemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	public ArrayList<String> getListaGanadores() 
	{
		ArrayList<String> resultado = new ArrayList<String>();
		try 
		{
			resultado = juego.getListaGanadores();
		} catch (RemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return resultado;
	}
	public boolean partidaEnJuego() 
	{
		boolean enJuego=false;
		try {
			enJuego = (juego.getEstado() != ESTADO.FINALIZADO);
		} catch (RemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return enJuego;
	}
}
	
	

	/*public void estoyListo() {
		juego.jugadorListo(jugadorUsandoControlador);
	}*/

	

