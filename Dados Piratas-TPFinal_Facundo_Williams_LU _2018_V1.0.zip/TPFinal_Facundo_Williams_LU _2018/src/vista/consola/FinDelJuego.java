package vista.consola;

import java.util.Scanner;

import controlador.Controlador;

public class FinDelJuego extends Menu{

	public FinDelJuego(Controlador controlador, VistaConsola vista) {
		super(controlador, vista);
	}

	@Override
	public void mostrar() {
		Scanner Scanner = new Scanner(System.in);
		String op;
		String ganador;
		try {
			ganador = controlador.getGanador().getNombre();

		System.out.println("$$$ Dados Piratas $$$");
		System.out.println("El ganador es el jugador: " + ganador +" !!!");
		System.out.println("Gracias por jugar.");
		System.out.println("|1| - Volver a jugar");
		System.out.println("|2| - Salir");
		System.out.println("Un juego de Facundo Williams");	
		System.out.println("Desarrollado para la asginatura Programacion Orientada a Objetos.");
		System.out.println("Universidad Nacional de Lujan.");
		op = Scanner.nextLine();
		System.out.println("opcion ingresada: [" + op+ "]");
		
		switch (op){
		case "1": 
			controlador.configurar();
			break;
		case "2":
			System.exit(0);
			break;
		default: System.out.println("�Elegir una opcion valida!");
		vista.mostrarJugando();
		break;
		}
		Scanner.close();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
