package vista.consola;

import java.rmi.RemoteException;

import controlador.Controlador;

public abstract class Menu {
	protected Controlador controlador;
	protected VistaConsola vista;
	public abstract void mostrar() throws RemoteException;
	public Menu(Controlador controlador, VistaConsola vista) {
		this.controlador = controlador;
		this.vista = vista;
	}

}
