package vista.consola;

import java.rmi.RemoteException;
import java.util.Scanner;

import controlador.Controlador;
import modelo.IJugador;

public class MenuJugando extends Menu {

	public MenuJugando(Controlador controlador, VistaConsola vista) throws RemoteException
	{
		super(controlador,vista);
	}

	@Override
	public void mostrar() throws RemoteException 
	{
		boolean primerTurno = controlador.primerTurno();
		Scanner scanner = new Scanner(System.in);
		String op;
		String cant;
		String valor;
		IJugador jugadorEnTurno = controlador.getJugadorEnTurno();
		//IJugador ultimoJugadorPropuso = controlador.getUltimoJugadorPropuso();
		System.out.println("$$$$$$$$$$$$$$$$$$$$ Partida en juego $$$$$$$$$$$$$$$$$$$$$$$$$$");
		if  (!primerTurno)//si no es el primer turno entonces alguien ya hizo una proposicion
			System.out.println("Ultima proposicion: "+ vista.getUltimaProposicion());	
		System.out.println("Es el turno de " + jugadorEnTurno.getNombre() );
		System.out.println("Cantidad de dados actual: " + Integer.valueOf(controlador.getCantDados(jugadorEnTurno)));
		System.out.println("Valores  de los dados determinados por el azar: ");
		vista.mostrarValoresJugador(jugadorEnTurno);
		System.out.println("Jugadas posibles...");
		if  (!primerTurno) 
			System.out.println("|1| - Subir Apuesta (debes superar la apuesta anterior)(decir que hay al menos 'x' dados de 'y' valor)");
		else
			System.out.println("|1| - Hacer Apuesta (cantidad minima: 2)(decir que hay al menos 'x' dados de 'y' valor)");//en el primer turno no hay apuesta que subir...
		if  (!primerTurno)//si no es el primer turno entonces alguien ya hizo una proposicion
			System.out.println("|2| - Llamar al oponente mentiroso(su proposicion es falsa)");
		System.out.println("|3| - Hacer una apuesta segura(decir que hay exactamente una cantidad 'x' de dados de 'y' valor)");
		System.out.println("|0| - Claudicar"); 
		System.out.println();
		System.out.println("Realizar jugada ==> ");
		op = scanner.nextLine();
		System.out.println("opcion ingresada: [" + op+ "]");
		switch (op){
		case "1": 
			System.out.println("Subiento apuesta...");
			System.out.println("Determinar cantidad de dados");
			cant = scanner.nextLine();
			System.out.println("Determinar un valor de cara");
			valor = scanner.nextLine();			
			controlador.subirApuesta(Integer.valueOf(cant), Integer.valueOf(valor));
			break;
		case "2":
			if  (!primerTurno) {
				System.out.println("Haz llamado al oponente mentiroso...");
				vista.mostrarTodosLosDados();
				controlador.oponenteMiente();
			}
			else
				System.out.println("�Elegir una opcion valida!");
				vista.mostrarJugando();
			break;
			
		case "3" :
			System.out.println("�Apuesta Segura!");
			System.out.println("Determinar cantidad de dados");
			cant = scanner.nextLine();
			System.out.println("Determinar un valor de cara");
			valor = scanner.nextLine();	
			if(controlador.validarCantDados(Integer.valueOf(cant)) && controlador.validarCara(Integer.valueOf(valor)))
					{
						vista.mostrarTodosLosDados();
						controlador.apuestaSegura(Integer.valueOf(cant),Integer.valueOf(valor));
					}
			else
				vista.mostrarJugando();
			break;
		case "0": System.out.println(jugadorEnTurno.getNombre()+" se ha rendido!");
					controlador.rendirse();
				break;
			
		default: System.out.println("�Elegir una opcion valida!");
				vista.mostrarJugando();
				break;
		}
		
		scanner.close();
	}

}
