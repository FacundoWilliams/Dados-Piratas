package vista.Grafica;

import java.awt.HeadlessException;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import controlador.Controlador;

import java.awt.Toolkit;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JSpinner;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.SpinnerNumberModel;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.event.ActionListener;
import java.rmi.RemoteException;
import java.util.ArrayList;
import java.awt.event.ActionEvent;

import modelo.IJugador;
import javax.swing.JList;
import javax.swing.JScrollPane;
import java.awt.Font;
import java.awt.Cursor;
import javax.swing.ImageIcon;

@SuppressWarnings("serial")
public class VentanaConfig extends JFrame {
	//private Controlador controlador;

	private JPanel contentPane;
	private JButton btnReglasDelJuego;
	private JList<String> jugadoresList;
	
	//componentes modelo, cuando se actualice listajugadores tambien lo hara la lista del scrollPane
	DefaultListModel<String> listaJugadores = new DefaultListModel<String>();
	

	/**
	 * Launch the application.
	 */
	/*public static void main(String[] args) {//TODO Solo para probar, luego lo llamo desde VistaConsola
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					VentanaConfig frame = new VentanaConfig(new Controlador());
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}*/

	/**
	 * Create the frame.
	 */
	public VentanaConfig(Controlador controlador) 
	{
		this.setVisible(true);
		//this.controlador.setModeloRemoto(new Juego());//TODO boorrar, es solo de prueba
		//this.controlador.agregarJugador("muy bien");
		/*try {
			SetListaJugadores(controlador.getJugadores());
		} catch (RemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}*/
		iniciarComponentes(controlador);
		crearEventos(controlador);

	}

	///////////////////////////////////////////////////////////////////////////////////////
	////////Este metodo contiene el codigo para crear e iniciar los componentes////////////
	///////////////////////////////////////////////////////////////////////////////////////
	private void iniciarComponentes(Controlador controlador)
	{
		setIconImage(Toolkit.getDefaultToolkit().getImage(VentanaConfig.class.getResource("/recursos/icono_64x64.png")));
		setTitle("\u00A1Dados Piratas! - Ventana de configuracion");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 725, 407);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		
		btnReglasDelJuego = new JButton("Mostrar reglas del juego");
		JSpinner cantDados = new JSpinner();
		cantDados.setModel(new SpinnerNumberModel(5, 1, 10, 1));
		cantDados.setValue(5);
		
		JLabel lblCantidadDeDados = new JLabel("Cantidad de dados:");
		
		JLabel lblCantidadDeCaras = new JLabel("Cantidad de caras:");
		
		JSpinner cantCaras = new JSpinner();
		cantCaras.setCursor(Cursor.getPredefinedCursor(Cursor.DEFAULT_CURSOR));
		cantCaras.setFont(new Font("Tahoma", Font.PLAIN, 11));
		cantCaras.setModel(new SpinnerNumberModel(6, 2, 12, 1));
		
		JLabel lblJugadoresConectados = new JLabel("Jugadores conectados:");
		lblJugadoresConectados.setFont(new Font("Tahoma", Font.BOLD, 13));
		
		JScrollPane scrollPane = new JScrollPane();
		
		JButton btnNewButton = new JButton("\u00A1Listo para iniciar la partida!");
		btnNewButton.addActionListener(new ActionListener() {
////////////////////////////////////////////////////////////////////////boton iniciar partida///////////////////////////////////////////////			
			public void actionPerformed(ActionEvent arg0) 
			{
				try {
					if(controlador.getJugadores().size() < 2)
						JOptionPane.showMessageDialog(null, "Deben haber por lo menos 2 jugadores para poder iniciar la partida", "Faltan jugadores", 1);
					else
					{
						JOptionPane.showMessageDialog(null, "Iniciando partida", "Comenzando...", 1);

						//le paso al controlador la cantidad de dados y caras y luego que inicie la partida
						/*int prueba=(int)cantDados.getValue();
						System.out.println("CATIDAD DE DADOS ELEGIDOS "+ prueba);
						//System.out.println("CATIDAD DE CARAS ELEGIDOS "+cantCaras.getValue());*/
						controlador.definirCantMaxDados((int)cantDados.getValue());
						controlador.definirCantMaxCaras((int)cantCaras.getValue());
						controlador.iniciarPartida();	
					}
				} catch (HeadlessException | RemoteException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				};
			}
		});
		btnNewButton.setIcon(new ImageIcon(VentanaConfig.class.getResource("/recursos/ship.png")));
		
		JLabel lblConfiguracion = new JLabel("Configuracion:");
		lblConfiguracion.setFont(new Font("Tahoma", Font.BOLD, 13));
		
		JLabel label_1 = new JLabel("");
		label_1.setIcon(new ImageIcon(VentanaConfig.class.getResource("/recursos/compass.png")));
		
		JLabel label_2 = new JLabel("");
		
		JLabel label_3 = new JLabel("");
		label_3.setIcon(new ImageIcon(VentanaConfig.class.getResource("/recursos/compass(1).png")));
		GroupLayout gl_contentPane = new GroupLayout(contentPane);
		gl_contentPane.setHorizontalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addContainerGap()
					.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
						.addGroup(gl_contentPane.createSequentialGroup()
							.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
								.addComponent(lblCantidadDeDados, GroupLayout.DEFAULT_SIZE, 250, Short.MAX_VALUE)
								.addGroup(gl_contentPane.createSequentialGroup()
									.addGroup(gl_contentPane.createParallelGroup(Alignment.TRAILING, false)
										.addComponent(cantDados, Alignment.LEADING, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
										.addComponent(lblCantidadDeCaras, Alignment.LEADING, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
										.addComponent(cantCaras, Alignment.LEADING, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
										.addComponent(btnReglasDelJuego, Alignment.LEADING))
									.addPreferredGap(ComponentPlacement.RELATED, 101, Short.MAX_VALUE))
								.addGroup(gl_contentPane.createSequentialGroup()
									.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
										.addGroup(gl_contentPane.createSequentialGroup()
											.addComponent(label_3)
											.addPreferredGap(ComponentPlacement.RELATED)
											.addComponent(label_1))
										.addComponent(lblConfiguracion))
									.addGap(179)))
							.addPreferredGap(ComponentPlacement.RELATED)
							.addComponent(label_2)
							.addGap(193))
						.addGroup(gl_contentPane.createSequentialGroup()
							.addComponent(btnNewButton, GroupLayout.PREFERRED_SIZE, 443, GroupLayout.PREFERRED_SIZE)
							.addPreferredGap(ComponentPlacement.RELATED)))
					.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
						.addComponent(lblJugadoresConectados)
						.addComponent(scrollPane, GroupLayout.DEFAULT_SIZE, 236, Short.MAX_VALUE))
					.addContainerGap())
		);
		gl_contentPane.setVerticalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addContainerGap()
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblConfiguracion)
						.addComponent(lblJugadoresConectados))
					.addPreferredGap(ComponentPlacement.RELATED)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
						.addGroup(gl_contentPane.createSequentialGroup()
							.addGroup(gl_contentPane.createParallelGroup(Alignment.TRAILING)
								.addGroup(gl_contentPane.createSequentialGroup()
									.addComponent(label_2)
									.addGap(33))
								.addGroup(gl_contentPane.createSequentialGroup()
									.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
										.addComponent(label_1)
										.addComponent(label_3))
									.addGap(12)))
							.addComponent(lblCantidadDeDados)
							.addPreferredGap(ComponentPlacement.UNRELATED)
							.addComponent(cantDados, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
							.addGap(18)
							.addComponent(lblCantidadDeCaras)
							.addGap(18)
							.addComponent(cantCaras, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
							.addGap(18)
							.addComponent(btnReglasDelJuego)
							.addPreferredGap(ComponentPlacement.RELATED, 29, Short.MAX_VALUE)
							.addComponent(btnNewButton, GroupLayout.PREFERRED_SIZE, 65, GroupLayout.PREFERRED_SIZE))
						.addComponent(scrollPane, GroupLayout.DEFAULT_SIZE, 326, Short.MAX_VALUE)))
		);
		
		jugadoresList = new JList<String>(listaJugadores);
		scrollPane.setViewportView(jugadoresList);
		contentPane.setLayout(gl_contentPane);
		try {
			setListaJugadores(controlador.getJugadores());
		} catch (RemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	///////////////////////////////////////////////////////////////////////////////////////
	//////////////Este metodo contiene el codigo para crear eventos////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////
	private void crearEventos(Controlador controlador) 
	{
		btnReglasDelJuego.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			try {
				JOptionPane.showMessageDialog(null, controlador.getInstrucciones(), "Reglas del Juego",1); 
				//JOptionPane.showMessageDialog(parentComponent, message, title, MAXIMIZED_BOTH);
			} catch (HeadlessException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (RemoteException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			}
		});
	}
	
	public void setListaJugadores(ArrayList<IJugador> jugadores) 
	{
		//listaJugadores = new DefaultListModel<String>();
		for(IJugador j:jugadores)
			try {
				listaJugadores.addElement(j.getNombre());
			} catch (RemoteException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	}

}
