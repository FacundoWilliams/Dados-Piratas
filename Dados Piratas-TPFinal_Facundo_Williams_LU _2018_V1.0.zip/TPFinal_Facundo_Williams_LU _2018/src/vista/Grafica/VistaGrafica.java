package vista.Grafica;

import java.rmi.RemoteException;

import controlador.Controlador;
import controlador.IVista;
import modelo.IJugador;

public class VistaGrafica implements IVista {
	
	private Controlador controlador;
	private VentanaConfig vConfig;
	private VentanaJugando vJugando;
	private VentanaFin vFin;
	private VentanaNombre vNombre;
	//private Mensaje vMensaje;
	private VentanaEsperandoTurno vEsperar;
	
	
	public VistaGrafica (Controlador controlador) {
		super();
		//vConfig.setVisible(false);
		vNombre = new VentanaNombre(controlador,this);
        vNombre.setVisible(false);     
		//vFin.setVisible(false);
		//vJugando.setVisible(false);
		this.controlador = controlador;
		this.controlador.setVista(this);
		vEsperar= new VentanaEsperandoTurno();
		vEsperar.setVisible(false);
	}

	@Override
	public void mostrarConfigurando() 
	{
		vNombre.setVisible(false);
		//vNombre.dispose();
		if (vConfig != null)
			vConfig.dispose();//cierrro la ventana anterior para actualizarla con la nueva instancia
		vConfig = new VentanaConfig(controlador);

	}

	@Override
	public void mostrarJugando()
	{		
		if (controlador.partidaEnJuego())
		{
			if(controlador.esMiTurno())
			{
				vEsperar.setVisible(false);	
				vConfig.setVisible(false);
				if (vJugando == null)
					vJugando = new VentanaJugando(controlador);
				//vJugando.setVisible(true);
				vJugando.iniciarComponentes(controlador);
				vJugando.setVisible(true);
			}
			else
			{
				if (vJugando == null)
					vJugando = new VentanaJugando(controlador);
				vConfig.setVisible(false);
				//vConfig.dispose();
				vJugando.setVisible(false);
				vEsperar.setVisible(true);
			}
		}
	}

	@Override
	public void desconfiaPierde() 
	{
		try {
			vJugando.mostrarResultado("El jugador "+ controlador.getUltimoJugadorPropuso().getNombre()  +" no miente, pierdes un dado!");
		} catch (RemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}		
		vJugando.iniciarComponentes(controlador);

	}

	@Override
	public void desconfiaGana()
{
		try {
			vJugando.mostrarResultado("El jugador "+ controlador.getUltimoJugadorPropuso().getNombre()  +" miente, pierde un dado!");
		} catch (RemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}		
		vJugando.iniciarComponentes(controlador);
	}

	@Override
	public void mostrarFinDelJuego() 
	{
		vJugando.setVisible(false);
		vEsperar.setVisible(false);
		vFin = new VentanaFin(controlador);
		vFin.setVisible(true);
		
	}

	@Override
	public void mostrarMensaje(String mensaje) 
	{
		if (vJugando !=null)
			vJugando.mostrarResultado(mensaje);		
	}

	@Override
	public void apuestaSeguraGana() 
	{
		try {
			vJugando.mostrarResultado("El jugador "+ controlador.getUltimoJugadorPropuso().getNombre() +" gana la apuesta segura! Todos los jugadores pierden un dado.");
		} catch (RemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		//vMensaje.dispose();	
		
	}

	@Override
	public void apuestaSeguraPierde() 
	{
		if(vJugando.isVisible())
		{
			try {
				vJugando.mostrarResultado("El jugador "+ controlador.getUltimoJugadorPropuso().getNombre() +" pierde apuesta segura! Por lo tanto pierde un dado.");
			} catch (RemoteException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			//vMensaje.dispose();
		}
		
	}

	@Override
	public void mostrarTodosLosDados() {
		// TODO Auto-generated method stub
		
	}


	@Override
	public void mostrarValoresJugador(IJugador jugador) {
		try {
			vJugando.mostrarValores(jugador.getValoresDados());
		} catch (RemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	@Override
	public void iniciar() {
		vNombre.setVisible(true);//muestro la ventana de inicio
		
	}

}
