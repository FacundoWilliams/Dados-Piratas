package vista.Grafica;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import controlador.Controlador;
import java.awt.Toolkit;
import java.rmi.RemoteException;

import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.JRadioButton;
import javax.swing.ButtonGroup;
import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.ImageIcon;
import javax.swing.border.TitledBorder;
import javax.swing.JSpinner;
import javax.swing.SpinnerNumberModel;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JScrollPane;
import javax.swing.JList;

@SuppressWarnings("serial")
public class VentanaJugando extends JFrame {

	/**
	 * 
	 */
	private JPanel contentPane;
	private JLabel etProposicion;
	private JPanel panelDados;
	private JLabel dado6;
	private JLabel dado5;
	private JLabel dado1;
	private JLabel dado2;
	private JLabel dado3;
	private JLabel dado11;
	private JLabel dado10;
	private JLabel dado8;
	private JLabel dado7;
	private JLabel dado4;
	private JLabel dado12;
	private JLabel dado9;
	DefaultListModel<String> listaHistorialJugadas = new DefaultListModel<String>();
	private JList<String> listaJugadas;
	private final ButtonGroup jugadasRdbtn = new ButtonGroup();

	/**
	 * Launch the application.
	 */
	/*
	public static void main(String[] args) {//TODO Solo para probar, luego lo llamo desde VistaConsola
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					VentanaJugando frame = new VentanaJugando(new Controlador());
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public VentanaJugando(Controlador controlador)
	{
		iniciarComponentes(controlador);
		crearEventos();
		this.setVisible(true);
	
	}

	///////////////////////////////////////////////////////////////////////////////////////
	//////////////Este metodo contiene el codigo para crear eventos////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////
	private void crearEventos() {
		
		
	}

	///////////////////////////////////////////////////////////////////////////////////////
	////////Este metodo contiene el codigo para crear e iniciar los componentes////////////
	///////////////////////////////////////////////////////////////////////////////////////
	protected void iniciarComponentes(Controlador controlador) 
	{

		listaJugadas = new JList<String>(listaHistorialJugadas);//Lista del scroll pane		

		setIconImage(Toolkit.getDefaultToolkit().getImage(VentanaJugando.class.getResource("/recursos/Icono_32x32.png")));
		try {
			setTitle("�Dados Piratas! - Partida en juego"+"- Ventana del jugador "+controlador.getJugadorEnTurno().getNombre());
		} catch (RemoteException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 965, 612);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5)); 
		setContentPane(contentPane);
		
		JLabel lblUltimaProposicion = new JLabel("Ultima Proposicion:");
		lblUltimaProposicion.setFont(new Font("Tahoma", Font.BOLD, 13));
		etProposicion = new JLabel();
		
		//Solo si no es el primer turno(o sea solo si hubo una proposicion en el turno anterior)==> muestro la ultima proposicion
		try {
			if ( ! (controlador.primerTurno()) )
			{
				try {
					etProposicion.setText("El jugador "+controlador.getUltimoJugadorPropuso().getNombre()+" propone: "
				+"Hay "+controlador.getUltimaProposicionCant()+" dados del valor "+controlador.getUltimaProposicionValor());
				} catch (RemoteException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		} catch (RemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		JLabel label = new JLabel("Jugadas posibles:");
		label.setFont(new Font("Tahoma", Font.BOLD, 13));
		
		JRadioButton rdbtnSubirApuesta = new JRadioButton("Subir Apuesta(apuesto que hay al menos)");
		rdbtnSubirApuesta.setSelected(true);
		jugadasRdbtn.add(rdbtnSubirApuesta);
		
		JRadioButton rdbtnApuestaSegura = new JRadioButton("Apuesta Segura(estoy seguro de que hay)");
		jugadasRdbtn.add(rdbtnApuestaSegura);
		
		JRadioButton rdbtnOponenteMiente = new JRadioButton("Llamar mentiroso al ultimo jugador que propuso(su proposicion es falsa)");
		jugadasRdbtn.add(rdbtnOponenteMiente);
		
		JRadioButton rdbtnRendirse = new JRadioButton("Rendirse");
		jugadasRdbtn.add(rdbtnRendirse);
		
		JButton btnNewButton = new JButton("Realizar Jugada");
	
		btnNewButton.setIcon(new ImageIcon(VentanaJugando.class.getResource("/recursos/head-with-games.png")));
		
		JLabel coin = new JLabel("");
		coin.setIcon(new ImageIcon(VentanaJugando.class.getResource("/recursos/coin(1).png")));
		
		JLabel apuestaSegura = new JLabel("");
		apuestaSegura.setIcon(new ImageIcon(VentanaJugando.class.getResource("/recursos/treasure(1).png")));
		
		JLabel mentiroso = new JLabel("");
		mentiroso.setIcon(new ImageIcon(VentanaJugando.class.getResource("/recursos/octopus(1).png")));
		
		JLabel rendirse = new JLabel("");
		rendirse.setIcon(new ImageIcon(VentanaJugando.class.getResource("/recursos/shipwreck(1).png")));
		
		panelDados = new JPanel();
		panelDados.setBorder(new TitledBorder(null, "Mis dados", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		
		JSpinner cantDadosSubirA = new JSpinner();
		try {
			if(controlador.getUltimaProposicionCant()+1 <= controlador.getCantDadosTodos())
				cantDadosSubirA.setModel(new SpinnerNumberModel(controlador.getUltimaProposicionCant()+1, controlador.getUltimaProposicionCant()+1, controlador.getCantDadosTodos(), 1));
		} catch (RemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		JLabel lblDados = new JLabel("Dados:");
		lblDados.setIcon(new ImageIcon(VentanaJugando.class.getResource("/recursos/dice.png")));
		
		JLabel lblCara = new JLabel("Cara:");
		lblCara.setIcon(new ImageIcon(VentanaJugando.class.getResource("/recursos/32x32_que_cara.png")));
		
		JSpinner cantCarasSubirA = new JSpinner();
		cantCarasSubirA.setModel(new SpinnerNumberModel(1, 1, controlador.getCantCaras(), 1));
		
		JSpinner cantCarasAS = new JSpinner();
		cantCarasAS.setModel(new SpinnerNumberModel(1, 1, controlador.getCantCaras(), 1));
		
		JLabel label_2 = new JLabel("Cara:");
		label_2.setIcon(new ImageIcon(VentanaJugando.class.getResource("/recursos/32x32_que_cara.png")));
		
		JSpinner cantDadosAS = new JSpinner();
		cantDadosAS.setModel(new SpinnerNumberModel(2, 2, controlador.getCantDadosTodos(), 1));
		
		JLabel label_3 = new JLabel("Dados:");
		label_3.setIcon(new ImageIcon(VentanaJugando.class.getResource("/recursos/dice.png")));
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBorder(new TitledBorder(null, "Historial de jugadas:", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		GroupLayout gl_contentPane = new GroupLayout(contentPane);
		gl_contentPane.setHorizontalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
						.addComponent(label, Alignment.TRAILING, GroupLayout.DEFAULT_SIZE, 814, Short.MAX_VALUE)
						.addGroup(Alignment.TRAILING, gl_contentPane.createSequentialGroup()
							.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
								.addGroup(gl_contentPane.createSequentialGroup()
									.addComponent(coin)
									.addPreferredGap(ComponentPlacement.RELATED)
									.addComponent(rdbtnSubirApuesta, GroupLayout.DEFAULT_SIZE, 505, Short.MAX_VALUE)
									.addGap(32))
								.addGroup(gl_contentPane.createSequentialGroup()
									.addComponent(apuestaSegura, GroupLayout.PREFERRED_SIZE, 32, GroupLayout.PREFERRED_SIZE)
									.addPreferredGap(ComponentPlacement.RELATED)
									.addComponent(rdbtnApuestaSegura, GroupLayout.DEFAULT_SIZE, 537, Short.MAX_VALUE)))
							.addGap(18)
							.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
								.addGroup(gl_contentPane.createSequentialGroup()
									.addComponent(lblDados)
									.addPreferredGap(ComponentPlacement.RELATED)
									.addComponent(cantDadosSubirA, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
									.addGap(18)
									.addComponent(lblCara, GroupLayout.PREFERRED_SIZE, 71, GroupLayout.PREFERRED_SIZE)
									.addPreferredGap(ComponentPlacement.RELATED)
									.addComponent(cantCarasSubirA, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
								.addGroup(gl_contentPane.createSequentialGroup()
									.addComponent(label_3, GroupLayout.PREFERRED_SIZE, 70, GroupLayout.PREFERRED_SIZE)
									.addGap(4)
									.addComponent(cantDadosAS, GroupLayout.PREFERRED_SIZE, 31, GroupLayout.PREFERRED_SIZE)
									.addGap(18)
									.addComponent(label_2, GroupLayout.PREFERRED_SIZE, 71, GroupLayout.PREFERRED_SIZE)
									.addGap(4)
									.addComponent(cantCarasAS, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))))
						.addGroup(Alignment.TRAILING, gl_contentPane.createSequentialGroup()
							.addComponent(mentiroso, GroupLayout.PREFERRED_SIZE, 32, GroupLayout.PREFERRED_SIZE)
							.addPreferredGap(ComponentPlacement.RELATED)
							.addComponent(rdbtnOponenteMiente, GroupLayout.DEFAULT_SIZE, 782, Short.MAX_VALUE))
						.addGroup(Alignment.TRAILING, gl_contentPane.createSequentialGroup()
							.addComponent(rendirse, GroupLayout.PREFERRED_SIZE, 32, GroupLayout.PREFERRED_SIZE)
							.addPreferredGap(ComponentPlacement.UNRELATED)
							.addComponent(rdbtnRendirse, GroupLayout.PREFERRED_SIZE, 80, GroupLayout.PREFERRED_SIZE))
						.addGroup(Alignment.TRAILING, gl_contentPane.createSequentialGroup()
							.addGap(10)
							.addComponent(scrollPane, GroupLayout.DEFAULT_SIZE, 804, Short.MAX_VALUE))
						.addComponent(etProposicion, GroupLayout.PREFERRED_SIZE, 527, GroupLayout.PREFERRED_SIZE))
					.addPreferredGap(ComponentPlacement.RELATED)
					.addComponent(panelDados, GroupLayout.PREFERRED_SIZE, 373, GroupLayout.PREFERRED_SIZE)
					.addContainerGap())
				.addComponent(btnNewButton, GroupLayout.DEFAULT_SIZE, 1203, Short.MAX_VALUE)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addComponent(lblUltimaProposicion)
					.addContainerGap())
		);
		gl_contentPane.setVerticalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addGroup(gl_contentPane.createParallelGroup(Alignment.TRAILING)
						.addGroup(gl_contentPane.createSequentialGroup()
							.addComponent(lblUltimaProposicion)
							.addPreferredGap(ComponentPlacement.UNRELATED)
							.addComponent(etProposicion, GroupLayout.PREFERRED_SIZE, 41, GroupLayout.PREFERRED_SIZE)
							.addPreferredGap(ComponentPlacement.RELATED, 7, Short.MAX_VALUE)
							.addComponent(label, GroupLayout.PREFERRED_SIZE, 16, GroupLayout.PREFERRED_SIZE)
							.addPreferredGap(ComponentPlacement.RELATED)
							.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
								.addGroup(gl_contentPane.createSequentialGroup()
									.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
										.addComponent(rdbtnSubirApuesta)
										.addComponent(coin))
									.addGap(18)
									.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
										.addComponent(apuestaSegura, GroupLayout.PREFERRED_SIZE, 32, GroupLayout.PREFERRED_SIZE)
										.addComponent(rdbtnApuestaSegura)))
								.addGroup(gl_contentPane.createSequentialGroup()
									.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
										.addComponent(lblDados)
										.addComponent(cantDadosSubirA, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
										.addComponent(cantCarasSubirA, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
										.addComponent(lblCara))
									.addPreferredGap(ComponentPlacement.UNRELATED)
									.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
										.addGroup(gl_contentPane.createSequentialGroup()
											.addGap(20)
											.addComponent(label_3, GroupLayout.PREFERRED_SIZE, 32, GroupLayout.PREFERRED_SIZE))
										.addGroup(gl_contentPane.createSequentialGroup()
											.addGap(26)
											.addComponent(cantDadosAS, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
										.addGroup(gl_contentPane.createSequentialGroup()
											.addGap(20)
											.addComponent(label_2, GroupLayout.PREFERRED_SIZE, 32, GroupLayout.PREFERRED_SIZE))
										.addGroup(gl_contentPane.createSequentialGroup()
											.addGap(26)
											.addComponent(cantCarasAS, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)))))
							.addPreferredGap(ComponentPlacement.RELATED)
							.addGroup(gl_contentPane.createParallelGroup(Alignment.TRAILING)
								.addComponent(mentiroso, GroupLayout.PREFERRED_SIZE, 32, GroupLayout.PREFERRED_SIZE)
								.addComponent(rdbtnOponenteMiente))
							.addPreferredGap(ComponentPlacement.UNRELATED)
							.addGroup(gl_contentPane.createParallelGroup(Alignment.TRAILING)
								.addComponent(rendirse, GroupLayout.PREFERRED_SIZE, 32, GroupLayout.PREFERRED_SIZE)
								.addComponent(rdbtnRendirse))
							.addGap(7)
							.addComponent(scrollPane, GroupLayout.PREFERRED_SIZE, 148, GroupLayout.PREFERRED_SIZE))
						.addGroup(gl_contentPane.createSequentialGroup()
							.addContainerGap()
							.addComponent(panelDados, GroupLayout.DEFAULT_SIZE, 406, Short.MAX_VALUE)))
					.addPreferredGap(ComponentPlacement.UNRELATED)
					.addComponent(btnNewButton, GroupLayout.PREFERRED_SIZE, 73, GroupLayout.PREFERRED_SIZE)
					.addContainerGap())
		);
		
		
		scrollPane.setViewportView(listaJugadas);
		
		dado6 = new JLabel("dado6");
		dado6.setIcon(new ImageIcon(VentanaJugando.class.getResource("/recursos/dado6.png")));
		//panelDados.add(dado6);
		
		dado5 = new JLabel("dado5");
		dado5.setIcon(new ImageIcon(VentanaJugando.class.getResource("/recursos/dado5.png")));
		//panelDados.add(dado5);
		
		dado1 = new JLabel("dado1");
		dado1.setIcon(new ImageIcon(VentanaJugando.class.getResource("/recursos/dado1.png")));
		//panelDados.add(dado1);
		
		dado2 = new JLabel("dado2");
		dado2.setIcon(new ImageIcon(VentanaJugando.class.getResource("/recursos/dado2.png")));
		//panelDados.add(dado2);
		
		dado3 = new JLabel("dado3");
		dado3.setIcon(new ImageIcon(VentanaJugando.class.getResource("/recursos/dado3.png")));
		//panelDados.add(dado3);
		
		dado11 = new JLabel("dado11");
		dado11.setIcon(new ImageIcon(VentanaJugando.class.getResource("/recursos/dado11.png")));
		//panelDados.add(dado11);
		
		dado10 = new JLabel("dado10");
		dado10.setIcon(new ImageIcon(VentanaJugando.class.getResource("/recursos/dado10.png")));
		//panelDados.add(dado10);
		
		dado8 = new JLabel("dado8");
		dado8.setIcon(new ImageIcon(VentanaJugando.class.getResource("/recursos/dado8.png")));
		//panelDados.add(dado8);
		
		dado7 = new JLabel("dado7");
		dado7.setIcon(new ImageIcon(VentanaJugando.class.getResource("/recursos/dado7.png")));
		//panelDados.add(dado7);
		
		dado4 = new JLabel("dado4");
		dado4.setIcon(new ImageIcon(VentanaJugando.class.getResource("/recursos/dado4.png")));
		//panelDados.add(dado4);
		
		dado12 = new JLabel("dado12");
		dado12.setIcon(new ImageIcon(VentanaJugando.class.getResource("/recursos/dado12.png")));
		//panelDados.add(dado12);
		
		dado9 = new JLabel("dado9");
		dado9.setIcon(new ImageIcon(VentanaJugando.class.getResource("/recursos/dado9.png")));
		//panelDados.add(dado9);
		contentPane.setLayout(gl_contentPane);
		//oculto todos los dados al comenzar


			//for (int i=0;i<12;i++)
		//panelDados.remove(dado1);
		//dado1.setVisible(true);
		//panelDados.add(dado1);
				
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) 
			{
////////////////CLICK EN REALIZAR JUGADA//////////////////////////////////////////////////////////////////////////////////////////////
				if(rdbtnRendirse.isSelected())
					controlador.rendirse();
				else
					if(rdbtnApuestaSegura.isSelected())
						controlador.apuestaSegura((int) cantDadosAS.getValue(), (int) cantCarasAS.getValue());//TODO casteo forzado
					else
						if(rdbtnOponenteMiente.isSelected())
							controlador.oponenteMiente();
						else
							controlador.subirApuesta((int)cantDadosSubirA.getValue(), (int)cantCarasSubirA.getValue());
													
			}
		});		


		
		try 
		{
			mostrarValores(controlador.getValoresDados());
		} catch (RemoteException e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		listaJugadas = new JList<String>(listaHistorialJugadas);
		
		
	}

	public void mostrarValores(int[] valoresDados)
	{
		panelDados.removeAll();//remuevo los dados anteriores
		//System.out.println("recibi un arreglo de longitud "+valoresDados.length);
		for (int i=0;i<valoresDados.length;i++)
		{
			//System.out.println("soy el valor "+valoresDados[i]);
			switch (valoresDados[i]) 
			{
				case 1: dado1 = new JLabel();
						dado1.setIcon(new ImageIcon(VentanaJugando.class.getResource("/recursos/dado1.png")));
						panelDados.add(dado1);
				break;
				case 2: dado2 = new JLabel();
				dado2.setIcon(new ImageIcon(VentanaJugando.class.getResource("/recursos/dado2.png")));
				panelDados.add(dado2);
				break;
				case 3: dado3 = new JLabel();
				dado3.setIcon(new ImageIcon(VentanaJugando.class.getResource("/recursos/dado3.png")));
				panelDados.add(dado3);
				break;
				case 4: dado4 = new JLabel();
				dado4.setIcon(new ImageIcon(VentanaJugando.class.getResource("/recursos/dado4.png")));
				panelDados.add(dado4);
				break;
				case 5: dado5 = new JLabel();
				dado5.setIcon(new ImageIcon(VentanaJugando.class.getResource("/recursos/dado5.png")));
				panelDados.add(dado5);
				break;
				case 6: dado6 = new JLabel();
				dado6.setIcon(new ImageIcon(VentanaJugando.class.getResource("/recursos/dado6.png")));
				panelDados.add(dado6);
				break;
				case 7: dado7 = new JLabel();
				dado7.setIcon(new ImageIcon(VentanaJugando.class.getResource("/recursos/dado7.png")));
				panelDados.add(dado7);
				break;
				case 8: dado8 = new JLabel();
				dado8.setIcon(new ImageIcon(VentanaJugando.class.getResource("/recursos/dado8.png")));
				panelDados.add(dado8);
				break;
				case 9: dado9 = new JLabel();
				dado9.setIcon(new ImageIcon(VentanaJugando.class.getResource("/recursos/dado9.png")));
				panelDados.add(dado9);
				break;
				case 10: dado10 = new JLabel();
				dado10.setIcon(new ImageIcon(VentanaJugando.class.getResource("/recursos/dado10.png")));
				panelDados.add(dado10);
				break;
				case 11: dado11 = new JLabel();
				dado11.setIcon(new ImageIcon(VentanaJugando.class.getResource("/recursos/dado11.png")));
				panelDados.add(dado11);
				break;
				case 12: dado12 = new JLabel();
				dado12.setIcon(new ImageIcon(VentanaJugando.class.getResource("/recursos/dado12.png")));
				panelDados.add(dado12);
				break;
				
			}
		}
	}

	public void mostrarResultado(String resultado) 
	{
		listaHistorialJugadas.addElement(resultado);
		
	}


}
