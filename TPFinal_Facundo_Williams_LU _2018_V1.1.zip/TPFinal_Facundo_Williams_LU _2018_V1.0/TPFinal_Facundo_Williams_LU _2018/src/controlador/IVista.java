package controlador;

import modelo.IJugador;

public interface IVista {

	void mostrarConfigurando();

	void mostrarJugando();

	void desconfiaPierde();

	void desconfiaGana();

	void mostrarFinDelJuego();

	void mostrarMensaje(String mensaje);

	void apuestaSeguraGana();

	void apuestaSeguraPierde();

	void mostrarTodosLosDados();

	//void mostrarInstrucciones();
	void mostrarValoresJugador(IJugador jugador);

	void iniciar();

}