package modelo;

import java.rmi.RemoteException;

public interface IJugador {
	public String getNombre()throws RemoteException;
	public int getCantidadDeDados()throws RemoteException;
	public int[] getValoresDados()throws RemoteException;
	public void restarDado()throws RemoteException;
	public void setCubilete(Cubilete cubilete)throws RemoteException;//el juego se encargar� de asignarle el cubilete al jugador
	public void tirarDados()throws RemoteException;
}
