package modelo;

import java.rmi.RemoteException;

public interface ICubilete {
	public void tirar() throws RemoteException;
	public int[] getValoresDados()throws RemoteException;
	public int getCantidadDeDados()throws RemoteException;
	public void restarDado()throws RemoteException;

}
