//facundowilliams10@gmail.com
package modelo;

import java.io.EOFException;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.Iterator;
import ar.edu.unlu.rmimvc.observer.ObservableRemoto;

public class Juego extends ObservableRemoto implements IJuego, Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = -5346990820253581340L;

	//estados posibles del juego:
	public static enum ESTADO {CONFIGURACION,JUGANDO,FINALIZADO};
	private ArrayList<Jugador> jugadores;
	private int maximoDeDados;
	private int maximoDeCaras;
	private int jugadorEnTurno;
	@SuppressWarnings("unused")//tira warning aunque ya esta el getter definido
	private int ganador;
	private ESTADO estadoDelJuego;
	private int ultimaProposicionCantDados;//la cantidad de dados apostada
	private int ultimaProposicionValorDados;//el valor de dado apostado
	private int ultimoJugadorPropuso;
	private int ronda;
	private int turnoNro;
	
	public Juego ()//throws RemoteException
	{
		jugadores = new ArrayList<>();
		maximoDeDados=5;
		maximoDeCaras=6;
		jugadorEnTurno=-1;
		ganador=-1;
		ultimaProposicionCantDados = 0;
		ultimaProposicionValorDados= -1;
		ultimoJugadorPropuso=-1;
		turnoNro=0;
		estadoDelJuego=ESTADO.CONFIGURACION;
		notificarCambio(CambiosModelo.ESTADO);
	}
	//posibles mejoras:
	//TODO agregar vista grafica
	//TODO implementar libreria rmi
	//TODO agregar musica en vista
	//TODO agregar selector de idioma en vista
	
	private void notificarCambio(CambiosModelo cambio) {
		try {
			notificarObservadores(cambio);
		} catch (RemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	/* (non-Javadoc)
	 * @see modelo.IControladorRemoto#agregarJugador(java.lang.String)
	 */
	/* (non-Javadoc)
	 * @see modelo.IJuego#agregarJugador(java.lang.String)
	 */
	@Override
	public void agregarJugador(String nombre)throws RemoteException
	{
		Jugador x = new Jugador(nombre);
		jugadores.add(x);
		notificarCambio(CambiosModelo.LISTA_JUGADORES);
	}
	
	/* (non-Javadoc)
	 * @see modelo.IControladorRemoto#definirCantDados(int)
	 */
	/* (non-Javadoc)
	 * @see modelo.IJuego#definirCantDados(int)
	 */
	@Override
	public void definirCantDados(int numeroDeDados) throws IllegalArgumentException,RemoteException
	{
		if (numeroDeDados>0 && numeroDeDados <11) {
			//valido que se defina una cantidad de dados en el rango [1;20]
			maximoDeDados = numeroDeDados;
		}
		else {		
			IllegalArgumentException error = new IllegalArgumentException("La cantidad de dados debe pertenecer al rango [1;10]");
			throw(error);
		}
	}
	
	/* (non-Javadoc)
	 * @see modelo.IControladorRemoto#finalizarPartida()
	 */
	/* (non-Javadoc)
	 * @see modelo.IJuego#finalizarPartida()
	 */
	@Override
	public void finalizarPartida() throws RemoteException
	{
		estadoDelJuego = ESTADO.FINALIZADO; 
		notificarCambio(CambiosModelo.ESTADO);	
	}
	
	/* (non-Javadoc)
	 * @see modelo.IControladorRemoto#iniciarPartida()
	 */
	/* (non-Javadoc)
	 * @see modelo.IJuego#iniciarPartida()
	 */
	@Override
	public void iniciarPartida()  throws Exception, RemoteException
	{//valido que haya minimo 2 jugadores
		if (jugadores.size()>1) {
			for(Jugador j:jugadores) 
				j.setCubilete(new Cubilete(maximoDeDados,maximoDeCaras));//un nuevo cubilete para cada jugador
			jugadorEnTurno = 0;// el primer jugador de la lista
			ultimoJugadorPropuso = 0;
			ronda = 0;
			tirarDados();
			notificarCambio(CambiosModelo.COMIENZA_EL_JUEGO);
		}
		else {
			Exception error = new Exception("Se intent� iniciar el juego con menos de 2 jugadores");
			throw(error);
		}
	}
	
	/* (non-Javadoc)
	 * @see modelo.IControladorRemoto#getJugadorEnTurno()
	 */
	/* (non-Javadoc)
	 * @see modelo.IJuego#getJugadorEnTurno()
	 */
	@Override
	public IJugador getJugadorEnTurno() throws Exception, RemoteException 
	{
		if (jugadorEnTurno <= jugadores.size() && jugadorEnTurno>=0)
			return jugadores.get(jugadorEnTurno);
		else
		{
			Exception e= new Exception("no se puede obtener el jugador en turno");
			throw e;
		}
			
	}
	
	/* (non-Javadoc)
	 * @see modelo.IControladorRemoto#tirarDados()
	 */
	/* (non-Javadoc)
	 * @see modelo.IJuego#tirarDados()
	 */
	@Override
	public void tirarDados() throws RemoteException
	{
		for(Jugador j:jugadores) {
			j.tirarDados();
		}
		turnoNro++;
	}
	
	private ArrayList<Integer> todosLosDados(){//devuelvo la lista con los valores de todos los dados
		ArrayList<Integer> valores = new ArrayList<>();
		int [] valoresUnJugador;
		for(Jugador j:jugadores) {
			valoresUnJugador=j.getValoresDados();
			for(int i=0;i<valoresUnJugador.length;i++)
				valores.add(valoresUnJugador[i]);
		}
		return valores;
		
	}
	
	/* (non-Javadoc)
	 * @see modelo.IControladorRemoto#verificarProposicion(int, int)
	 */
	/* (non-Javadoc)
	 * @see modelo.IJuego#verificarProposicion(int, int)
	 */
	@Override
	public boolean verificarProposicion(int cantidadDeDados, int valorDeCara) throws RemoteException
	{
		//para verificar que se cumpla la proposicion de una cierta cantidadde dados con un cierto valor
		//genero una lista con los valores de los dados de TODOS los jugadores y verifico
		ArrayList<Integer> valoresTodosLosDados = todosLosDados();
		int aciertos=0;//aumulador de valores que valen lo propuesto en valorDeCara
		for(int v:valoresTodosLosDados)
			if (v==valorDeCara)
				aciertos++;
		if(aciertos>=cantidadDeDados)
			//si la cantidad de valores es mayor o igual a la cantidadDeDados propuesta entonces la proposicion es verdadera
			return true;
		else
			return false;
	}
	
	/* (non-Javadoc)
	 * @see modelo.IControladorRemoto#desconfiar(modelo.IJugador, modelo.IJugador)
	 */
	/* (non-Javadoc)
	 * @see modelo.IJuego#desconfiar(modelo.IJugador, modelo.IJugador)
	 */
	@Override
	public void desconfiar() throws Exception,RemoteException//TODO cambiaron arguemntos..
	{
		if (estadoDelJuego != ESTADO.FINALIZADO)
		{
			ultimoJugadorPropuso = jugadorEnTurno;
			IJugador jugadorDesconfia = jugadores.get(jugadorEnTurno);
			IJugador jugadorPropone = jugadores.get(ultimoJugadorPropuso);
			if (turnoNro != 1)// si no es el primer turno de la ronda
			{
				if (verificarProposicion(ultimaProposicionCantDados,ultimaProposicionValorDados)) {
					/*si el jugador desconfia y la ultima proposicion es cierta, 
					el jugador que desconfia pierde un dado*/
					jugadorDesconfia.restarDado();
					cambiarRonda();
					notificarCambio(CambiosModelo.DESCONFIA_PIERDE);
				}
				else {
					/*si la proposicion es falsa entonces 
					pierde un dado el jugador que propuso la ultima apuesta*/
					jugadorPropone.restarDado();	
					cambiarRonda();
					notificarCambio(CambiosModelo.DESCONFIA_GANA);
					//despues de notificar no se ejecutara lo que queda del {}
				}
			}
			else
			{
				Exception e = new Exception("El jugador no puede desconfiar en el primer turno de una ronda.");
				throw e;
			}
		}
	}
	
	/* (non-Javadoc)
	 * @see modelo.IControladorRemoto#subirApuesta(int, int)
	 */
	/* (non-Javadoc)
	 * @see modelo.IJuego#subirApuesta(int, int)
	 */
	@Override
	public void subirApuesta(int cantDados, int valorDados)throws RemoteException
	{
		if(estadoDelJuego != ESTADO.FINALIZADO)
		{
			//cuando un jugador sube la apuesta se actualiza la ultima apuesta
			if (cantDados > ultimaProposicionCantDados && cantValida(cantDados) && caraValida(valorDados)) 
			{
				ultimaProposicionCantDados = cantDados;
				ultimaProposicionValorDados = valorDados;
				ultimoJugadorPropuso = jugadorEnTurno;	
				cambiarTurno();
			}
			else 
			{
				if (limiteApuestaAlcanzado())
					notificarCambio(CambiosModelo.LIMITE_APUESTA_ALCANZADO);
				else
					notificarCambio(CambiosModelo.APUESTA_INVALIDA);
			}
		}
	}
	
	private boolean limiteApuestaAlcanzado() 
	{
		if (ultimaProposicionCantDados >= maximoDeDados)
			return true;
		else
			return false;
	}

	private boolean cantValida(int cantDados) 
	{
		if ((cantDados > 0) && (cantDados <=maximoDeDados))
			return true;
		else
			return false;
	}

	private boolean caraValida(int valorDados) 
	{
		if ((valorDados>0) && (valorDados<=maximoDeCaras))
			return true;
		else
			return false;
	}
	/* (non-Javadoc)
	 * @see modelo.IControladorRemoto#apuestaSegura(int, int)
	 */
	/* (non-Javadoc)
	 * @see modelo.IJuego#apuestaSegura(int, int)
	 */
	@Override
	public void apuestaSegura(int apuestaCantDados, int apuestaValorDados) throws RemoteException
	{
		if(estadoDelJuego != ESTADO.FINALIZADO)
		{
			ultimoJugadorPropuso = jugadorEnTurno;
			ArrayList<Integer> valores = todosLosDados();
			int aciertos=0; 
			for(int v:valores)//TODO  podr�a mejorar la eficiencia con un while...
				if (apuestaValorDados == v)
					aciertos++;
			if (aciertos==apuestaCantDados) 
			{
				//si acierta TODOS los jugadores pierden un dado
				for (Jugador j:jugadores)
					j.restarDado();
				//cambiarTurno();
				cambiarRonda();
				notificarCambio(CambiosModelo.APUESTA_SEGURA_GANA);
			}
			else
			{//si no acierta el jugador pierde un dado
				jugadores.get(jugadorEnTurno).restarDado();
				cambiarRonda();
				notificarCambio(CambiosModelo.APUESTA_SEGURA_PIERDE);
			}
		}
	}

	/* (non-Javadoc)
	 * @see modelo.IControladorRemoto#getEstado()
	 */
	/* (non-Javadoc)
	 * @see modelo.IJuego#getEstado()
	 */
	@Override
	public ESTADO getEstado() throws RemoteException
	{
		return estadoDelJuego;
	}

	/* (non-Javadoc)
	 * @see modelo.IControladorRemoto#definirCantCaras(java.lang.Integer)
	 */
	/* (non-Javadoc)
	 * @see modelo.IJuego#definirCantCaras(java.lang.Integer)
	 */
	@Override
	public void definirCantCaras(Integer valueOf) throws IllegalArgumentException {
		if (valueOf>0 && valueOf <21) {
			//valido que se defina una cantidad de dados en el rango [1;20]
			maximoDeCaras = valueOf;
		}
		else {		
			IllegalArgumentException error = new IllegalArgumentException("La cantidad de caras de los dados debe pertenecer al rango [1;20]");
			throw(error);
		}
		
	}

	/* (non-Javadoc)
	 * @see modelo.IControladorRemoto#getUltimoJugadorPropuso()
	 */
	/* (non-Javadoc)
	 * @see modelo.IJuego#getUltimoJugadorPropuso()
	 */
	@Override
	public IJugador getUltimoJugadorPropuso() throws RemoteException
	{
		if(!jugadores.isEmpty() && estadoDelJuego != ESTADO.FINALIZADO)
			return jugadores.get(ultimoJugadorPropuso);
		else
			return null;
	}

	/* (non-Javadoc)
	 * @see modelo.IControladorRemoto#getGanador()
	 */
	/* (non-Javadoc)
	 * @see modelo.IJuego#getGanador()
	 */
	@Override
	public IJugador getGanador() throws Exception,RemoteException
	{
		if (jugadores.size() ==1)
			return jugadores.get(0);
		else
		{
			Exception e= new Exception("No hay ganador.");
			throw e;
		}
	}

	/* (non-Javadoc)
	 * @see modelo.IControladorRemoto#iniciarJuego()
	 */
	/* (non-Javadoc)
	 * @see modelo.IJuego#iniciarJuego()
	 */
	@Override
	public void iniciarJuego() throws RemoteException
	{
		estadoDelJuego = ESTADO.CONFIGURACION;
		notificarCambio(CambiosModelo.ESTADO);
	}

	/* (non-Javadoc)
	 * @see modelo.IControladorRemoto#getJugadores()
	 */
	/* (non-Javadoc)
	 * @see modelo.IJuego#getJugadores()
	 */
	@Override
	public ArrayList<IJugador> getJugadores() throws RemoteException
	{
		ArrayList<IJugador> js = new ArrayList<>();

		if (!(jugadores.isEmpty()))//si la lista no esta vacia
		{
		for (IJugador j : jugadores)
			js.add(j);
		}
		return js;
	}

	/* (non-Javadoc)
	 * @see modelo.IControladorRemoto#getUltimaProposicionCant()
	 */
	/* (non-Javadoc)
	 * @see modelo.IJuego#getUltimaProposicionCant()
	 */
	@Override
	public int getUltimaProposicionCant() throws RemoteException
	{
		return ultimaProposicionCantDados;
	}

	/* (non-Javadoc)
	 * @see modelo.IControladorRemoto#getUltimaProposicionValor()
	 */
	/* (non-Javadoc)
	 * @see modelo.IJuego#getUltimaProposicionValor()
	 */
	@Override
	public int getUltimaProposicionValor() throws RemoteException
	{
		return ultimaProposicionValorDados;
	}

	/* (non-Javadoc)
	 * @see modelo.IControladorRemoto#getTurno()
	 */
	/* (non-Javadoc)
	 * @see modelo.IJuego#getTurno()
	 */
	@Override
	public int getTurno() throws RemoteException
	{
		return turnoNro;
	}
	
	/* (non-Javadoc)
	 * @see modelo.IControladorRemoto#cambiarTurno()
	 */
	/* (non-Javadoc)
	 * @see modelo.IJuego#cambiarTurno()
	 */
	@Override
	public void cambiarTurno() throws RemoteException
	{
		turnoNro++;
		jugadorEnTurno = ++jugadorEnTurno % jugadores.size();
		//System.out.println("EL TURNO SERA DE" +jugadorEnTurno);
		if (hayGanador())
		{
			estadoDelJuego=ESTADO.FINALIZADO;
			notificarCambio(CambiosModelo.ESTADO);
		}
		else
			notificarCambio(CambiosModelo.TURNO);
	}
	
	private boolean hayGanador() {
		if (jugadores.size() <= 1 )
		{
			ganador = 0;//el unico jugador que queda en la lista
			return true;
		}
		else
			return false;
	}

	/* (non-Javadoc)
	 * @see modelo.IControladorRemoto#rendirse()
	 */
	/* (non-Javadoc)
	 * @see modelo.IJuego#rendirse()
	 */
	@Override
	public void rendirse() throws RemoteException
	{
		jugadores.remove(jugadorEnTurno);
		cambiarRonda();
	}
	private void cambiarRonda() {
		ronda++;
		turnoNro=1;
		jugadorEnTurno = ++jugadorEnTurno % jugadores.size();
		ultimaProposicionCantDados = 1;
		ultimaProposicionValorDados= -1;
		//antes de cambiar la ronda elimino de la lista los juadores que perdieron y verifico si hay ganador
		eliminarPerdedores();
		if (hayGanador()) {
			estadoDelJuego=ESTADO.FINALIZADO;
			notificarCambio(CambiosModelo.ESTADO);
		}
	}
	
	private void eliminarPerdedores() {
		//creo un iterador para poder eliminar elementos de la lista mientras la recorro
		Iterator<Jugador> i = jugadores.iterator();
		Jugador j;
		while(i.hasNext()) 
		{
			j = i.next();
			if ( j.getCantidadDeDados() < 1)
				i.remove();;
		}
	}
	/* (non-Javadoc)
	 * @see modelo.IControladorRemoto#getTodosLosDados()
	 */
	/* (non-Javadoc)
	 * @see modelo.IJuego#getTodosLosDados()
	 */
	@Override
	public int[] getTodosLosDados()throws RemoteException//devuelvo un cubilete con TODOS los dados en juego
	{
		int[] dados;
		ArrayList<Integer> todosDados = new ArrayList<Integer>();
		for(IJugador j:jugadores) {//guardo todos los dados en la lista todosDados
			dados = j.getValoresDados();
			for (int i=0;i<dados.length;i++)
				todosDados.add(dados[i]);
		}
		dados = new int[todosDados.size()];//devuelvo un arreglo con todos los dados
		int i=0;
		for (Integer dado:todosDados) {
			dados[i] = dado;
			i++;
		}
		return dados;
	}
	
	/* (non-Javadoc)
	 * @see modelo.IControladorRemoto#getRonda()
	 */
	/* (non-Javadoc)
	 * @see modelo.IJuego#getRonda()
	 */
	@Override
	public int getRonda() throws RemoteException
	{
		return ronda;
	}
	
	/* (non-Javadoc)
	 * @see modelo.IControladorRemoto#getInstrucciones()
	 */
	/* (non-Javadoc)
	 * @see modelo.IJuego#getInstrucciones()
	 */
	@Override
	public String getInstrucciones()throws RemoteException
	{
		return "Cada jugador tiene 5 dados al principio del juego y un cubilete. Al comenzar, todos los jugadores agitan los dados dentro del cubilete y lo posan sobre la mesa boca abajo.\r\n" + 
				"\r\n" + 
				"T� puedes mirar tus dados, pero no puedes ver los de los dem�s. "
				+"\r\n"+ "En tu turno, deber�s decir cuantos dados de un n�mero hay. Ej: 3 dados de cuatro. El siguiente jugador por la izquierda, tendr� la opci�n de desconfiar o aumentar el n�mero de dados que hay. "
				+"\r\n"+ "Si desconf�a se destapar�n los dados y se comprobar� el n�mero de dados sobre la mesa. Si ten�a raz�n y no hab�a tres dados de cuatro, perder�s un dado. Si por el contrario era cierto, �l perder� un dado.\r\n" + 
				"\r\n" + 
				"En caso de no desconfiar, y aumentar, dir� siempre un n�mero m�s alto de dados, independientemente de qu� n�mero sea. Ej: 4 dados de 2."
				+"\r\n"+ "Tambi�n existe la opci�n apuesta segura. Si est�s seguro de que en la mesa hay 4 dados de dos exactamente, puedes hacer una apuesta segura. Si aciertas, todos los jugadores perder�n un dado, si fallas, perder�s uno."
				+"\r\n"+ "El objetivo de este juego es dejar a todos los jugadores sin dados. ";
	}

	/* (non-Javadoc)
	 * @see modelo.IControladorRemoto#validarCara(java.lang.Integer)
	 */
	/* (non-Javadoc)
	 * @see modelo.IJuego#validarCara(java.lang.Integer)
	 */
	@Override
	public boolean validarCara(Integer valueOf) throws RemoteException
	{
		if (valueOf >0 && valueOf <= maximoDeCaras)
			return true;
		else
			return false;
	}

	/* (non-Javadoc)
	 * @see modelo.IControladorRemoto#validarCantDados(int)
	 */
	/* (non-Javadoc)
	 * @see modelo.IJuego#validarCantDados(int)
	 */
	@Override
	public boolean validarCantDados(int valueOf) throws RemoteException
	{
		if (valueOf >0 && valueOf <= maximoDeDados)
			return true;
		else
			return false;
	}

	@Override
	public int getCantCaras() throws RemoteException{
		return maximoDeCaras;
	}

	@Override
	public int getCantDadosTodos() throws RemoteException {
		int acumulador=0;
		for (IJugador j : jugadores)
			acumulador +=  j.getCantidadDeDados();
		return acumulador;
	}

	@Override
	public int getCantJugadores() throws RemoteException {
		return jugadores.size();
	}

	@Override
	public int getNroJugadorEnTurno() throws RemoteException {
		return jugadorEnTurno;
	}

	@Override
	public void guardarGanador() throws RemoteException
	{
		File ganadores = new File("ganadores.txt");
		if (!(ganadores.exists()))// si no existe el archivo escribo el primer objeto
		{
			String archivo = "ganadores.txt";
			try {
				ObjectOutputStream  oos = new ObjectOutputStream(new FileOutputStream(archivo,false));
				oos.writeObject(jugadores.get(0).getNombre());//el unico jugador que queda es el ganador del juego.
				oos.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		else//sino agrego al final
		{
			String archivo = "ganadores.txt";
			try {
				ObjectOutputStream  oos = new MyOOStream(new FileOutputStream(archivo,true));
				oos.writeObject(jugadores.get(0).getNombre());
				oos.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		
	}

	@Override
	public ArrayList<String> getListaGanadores() throws RemoteException 
	{
		File ganadores = new File("ganadores.txt");
		ArrayList<String> lista = new ArrayList<String>();
		if (ganadores.exists())
		{
			String archivo = "ganadores.txt";
			ObjectInputStream ois;
			try {
				ois = new ObjectInputStream(new FileInputStream(archivo));
				Object o = ois.readObject();
				while( o != null) {
					if (o instanceof String) {
						lista.add((String)o);
						o = ois.readObject();
					}
				}
				ois.close();
			} catch (ClassNotFoundException e) {
				e.printStackTrace();
			} catch (EOFException e) {
			 // No hago nada porque simplemente la lectura de objetos indico que el archivo llego a su fin	
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		return lista;
	}
	
}
