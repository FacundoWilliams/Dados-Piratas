package modelo;

import java.io.Serializable;
import java.util.ArrayList;

public class Cubilete implements ICubilete,Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 5406421622530307000L;
	private ArrayList<Dado> dados;
	/* se utiliza una estructura dinamica para guardar los dados
	 * pues se agregaran y eliminaran dados durante el transcurso del juego*/
	
	public Cubilete() {
		this(5,6);
	}
	
	public Cubilete(int cantidadDeDados,int cantidadDeCaras) {
		//validacion 
		if (cantidadDeDados < 1 || cantidadDeDados > 10)
			cantidadDeDados = 5;
		dados = new ArrayList<>(0) ;//Capacidad inicial de la lista = 0
		for (int i=0;i< cantidadDeDados;i++)
		{
			Dado d = new Dado(cantidadDeCaras);
			dados.add(d);
		}
	}
	
	public void tirar() {
		for (Dado d:dados)
			d.tirar();
	}

	public int[] getValoresDados(){  
	//devuelvo un array con los valores de los dados
		int i=0;
		int[] resultado = new int[dados.size()];
		for(Dado d: dados)
		{
			resultado[i]= d.getCara();
			i++;
		}
		return resultado;
	}
	
	public int getCantidadDeDados(){
		return dados.size();
		}
	
	public void restarDado() {
		if (! dados.isEmpty())//valido que la lista no este vacia
			dados.remove(0);// un dado dado de la lista
	}
}	
	
	
