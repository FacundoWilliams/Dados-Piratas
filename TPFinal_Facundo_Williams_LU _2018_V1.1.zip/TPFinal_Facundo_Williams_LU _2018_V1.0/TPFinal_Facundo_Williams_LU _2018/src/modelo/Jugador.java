package modelo;

import java.io.Serializable;

public class Jugador implements IJugador,Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 5081420508131618172L;
	private String nombre;
	private Cubilete cubilete;
	public Jugador(String nombre2) {
		nombre = nombre2;
	}
	@Override
	public String getNombre() {		
		return nombre;
	}
	@Override
	public int getCantidadDeDados() {
		return cubilete.getCantidadDeDados();
	}
	@Override
	public int[] getValoresDados() {
		return cubilete.getValoresDados();
	}
	@Override
	public void restarDado() {
		cubilete.restarDado();		
	}
	@Override
	public void setCubilete(Cubilete cubilete) {
		this.cubilete=cubilete;
		
	}
	@Override
	public void tirarDados() {
		cubilete.tirar();
		
	}

}
