package modelo;

import java.io.Serializable;
import java.util.Random;

public class Dado implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = -7934454143379575302L;
	private int cara;
	private int cantidadCaras;
	private Random aleatorio = new Random();
	
	public Dado() {
		this(6);
	}
	public Dado (int cantidadDeCaras) {
		//validacion
		if (cantidadDeCaras < 1 || cantidadDeCaras > 20)
			cantidadCaras = 6;
		else
			cantidadCaras= cantidadDeCaras;
		tirar();
	}
	void tirar() {
		//aleatorio = new Random();
		cara= aleatorio.nextInt(cantidadCaras)+1;
	}
	
	int getCara() {
		return cara;
	}
	
}
