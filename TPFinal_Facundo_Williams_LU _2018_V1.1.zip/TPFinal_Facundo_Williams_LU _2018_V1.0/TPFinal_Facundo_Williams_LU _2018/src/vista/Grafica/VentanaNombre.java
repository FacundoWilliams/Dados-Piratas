package vista.Grafica;

import java.awt.BorderLayout;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import controlador.Controlador;
import controlador.IVista;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JTextField;
import javax.swing.ImageIcon;
import javax.swing.LayoutStyle.ComponentPlacement;
import java.awt.Toolkit;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

@SuppressWarnings("serial")
public class VentanaNombre extends JDialog {

	private final JPanel contentPanel = new JPanel();
	private JLabel lblIngresarNombre;
	private JTextField inputNombre;
	/**
	 * Launch the application.
	 */
	/*public static void main(String[] args) {
		try {
			IngresarNombre dialog = new IngresarNombre(new Controlador());
			dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
			dialog.setVisible(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}*/

	/**
	 * Create the dialog.
	 */
	public VentanaNombre(Controlador controlador, IVista vista) 
	{
		try {
			this.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
			this.setVisible(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
		setIconImage(Toolkit.getDefaultToolkit().getImage(VentanaNombre.class.getResource("/recursos/Icono_32x32.png")));
		setTitle("\u00A1Bienvenid@ a Dados Piratas!");
		setBounds(100, 100, 356, 172);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.NORTH);
		{
			lblIngresarNombre = new JLabel("Ingresar nombre:");
		}
		
		inputNombre = new JTextField();
		inputNombre.setColumns(10);
		
		JLabel label = new JLabel("");
		
		JLabel label_1 = new JLabel("");
		label_1.setIcon(new ImageIcon(VentanaNombre.class.getResource("/recursos/pirate.png")));
		
		JLabel label_2 = new JLabel("");
		label_2.setIcon(new ImageIcon(VentanaNombre.class.getResource("/recursos/pirate(1).png")));
		
		JButton btnOk = new JButton("OK");
		btnOk.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) 
			{
				//JOptionPane.showMessageDialog(null, "PROBANDO EL CLICK EN BOTON OK,SE ECRIBIO LO SIGUEINTE:"+inputNombre.getText(), "ingresar nombre", 0);
				if (inputNombre.getText() == "")
					JOptionPane.showMessageDialog(null, "Debes ingresar un nombre para poder iniciar la partida", "ingresar nombre", 0);
				else
				{
					JOptionPane.showMessageDialog(null, "Bienvenid@ "+inputNombre.getText()+" !", "accediendo al menu configuracion", 1);

					controlador.agregarJugador(inputNombre.getText());//agrego al jugador 
					
					//vista.mostrarConfigurando();//cambio a la ventana configuracion
					
					//cerrar();
					
				}
			}
		});
		GroupLayout gl_contentPanel = new GroupLayout(contentPanel);
		gl_contentPanel.setHorizontalGroup(
			gl_contentPanel.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPanel.createSequentialGroup()
					.addGroup(gl_contentPanel.createParallelGroup(Alignment.LEADING)
						.addComponent(lblIngresarNombre, GroupLayout.DEFAULT_SIZE, 172, Short.MAX_VALUE)
						.addComponent(inputNombre, GroupLayout.PREFERRED_SIZE, 172, GroupLayout.PREFERRED_SIZE))
					.addPreferredGap(ComponentPlacement.RELATED)
					.addComponent(label_1, GroupLayout.PREFERRED_SIZE, 64, GroupLayout.PREFERRED_SIZE)
					.addGroup(gl_contentPanel.createParallelGroup(Alignment.LEADING)
						.addGroup(gl_contentPanel.createSequentialGroup()
							.addGap(170)
							.addComponent(label))
						.addGroup(gl_contentPanel.createSequentialGroup()
							.addGap(10)
							.addGroup(gl_contentPanel.createParallelGroup(Alignment.TRAILING)
								.addComponent(btnOk, GroupLayout.PREFERRED_SIZE, 68, GroupLayout.PREFERRED_SIZE)
								.addComponent(label_2, GroupLayout.PREFERRED_SIZE, 64, GroupLayout.PREFERRED_SIZE)))))
		);
		gl_contentPanel.setVerticalGroup(
			gl_contentPanel.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPanel.createSequentialGroup()
					.addGroup(gl_contentPanel.createParallelGroup(Alignment.LEADING)
						.addGroup(gl_contentPanel.createSequentialGroup()
							.addComponent(label_1)
							.addGap(11)
							.addComponent(label))
						.addGroup(gl_contentPanel.createSequentialGroup()
							.addComponent(lblIngresarNombre)
							.addPreferredGap(ComponentPlacement.UNRELATED)
							.addComponent(inputNombre, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
						.addComponent(label_2, GroupLayout.PREFERRED_SIZE, 64, GroupLayout.PREFERRED_SIZE))
					.addGap(16)
					.addComponent(btnOk)
					.addContainerGap(142, Short.MAX_VALUE))
		);
		contentPanel.setLayout(gl_contentPanel);
	}
	/*private void cerrar() 
	{
		this.dispose();
		
	}*/
}
