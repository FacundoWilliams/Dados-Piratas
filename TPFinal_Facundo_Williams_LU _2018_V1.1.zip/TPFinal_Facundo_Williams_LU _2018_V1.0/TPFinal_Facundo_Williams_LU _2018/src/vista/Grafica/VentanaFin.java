package vista.Grafica;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Toolkit;

import javax.swing.DefaultListModel;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.ImageIcon;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.JButton;
import javax.swing.JScrollPane;
import javax.swing.border.TitledBorder;

import controlador.Controlador;

import javax.swing.border.BevelBorder;
import javax.swing.JList;
import java.awt.event.ActionListener;
import java.rmi.RemoteException;
import java.util.ArrayList;
import java.awt.event.ActionEvent;

@SuppressWarnings("serial")
public class VentanaFin extends JFrame 
{
	private JList<String> listaGanadores;
	DefaultListModel<String> listaModeloGanadores = new DefaultListModel<String>();

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	/*public static void main(String[] args) {//TODO Solo para probar, luego lo llamo desde VistaConsola
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					VentanaFin frame = new VentanaFin();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}*/

	/**
	 * Create the frame.
	 */
	public VentanaFin(Controlador controlador) 
	{
		
		this.setVisible(true);
		
		setTitle("\u00A1Dados Piratas! - Fin del Juego");
		setIconImage(Toolkit.getDefaultToolkit().getImage(VentanaFin.class.getResource("/recursos/icono_64x64.png")));
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 731, 429);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		
		JLabel lblElGanadorEs = new JLabel("El ganador es: ");
		lblElGanadorEs.setFont(new Font("Tahoma", Font.BOLD, 15));
		
		JLabel ganador;
		ganador = new JLabel("ganador");
		ganador.setFont(new Font("Tahoma", Font.BOLD, 15));
		
		JLabel label = new JLabel("");
		label.setIcon(new ImageIcon(VentanaFin.class.getResource("/recursos/chest(1).png")));
		
		JLabel label_1 = new JLabel("");
		label_1.setIcon(new ImageIcon(VentanaFin.class.getResource("/recursos/treasure(2).png")));
		
		JLabel label_2 = new JLabel("");
		label_2.setIcon(new ImageIcon(VentanaFin.class.getResource("/recursos/treasure(2).png")));
		
		JLabel label_3 = new JLabel("");
		label_3.setIcon(new ImageIcon(VentanaFin.class.getResource("/recursos/treasure(4).png")));
		
		JLabel label_4 = new JLabel("");
		label_4.setIcon(new ImageIcon(VentanaFin.class.getResource("/recursos/treasure(3).png")));
		
		JLabel lblEsteJuegoHa = new JLabel("Este juego ha sido desarrollado por Facundo Williams, para la asignatura Programacion Orientada a Objetos");
		lblEsteJuegoHa.setFont(new Font("Tahoma", Font.BOLD, 13));
		
		JLabel label_6 = new JLabel("");
		label_6.setIcon(new ImageIcon(VentanaFin.class.getResource("/recursos/unlu_100x100.png")));
		
		JLabel lblGraciasPorJugar = new JLabel("Gracias por jugar!");
		lblGraciasPorJugar.setFont(new Font("Tahoma", Font.PLAIN, 12));
		
		JButton btnVolverAJugar = new JButton("Salir");
		btnVolverAJugar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) 
			{
///////////////////////////BOTON SALIR//////////////////////////////////////////////////////////////////////////////////////////////////
				System.exit(0);
			}
		});
////////////////////////////////////BOTON GUARDAR GANADOR, PERSISTENCIA DEL GANADOR//////////////////////////////////////////////////////////////////////////////////////////////
		JButton button = new JButton("Guardar ganador");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) 
			{
				controlador.guardarGanador();
				//System.exit(0);
			}
		});
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setViewportBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null));
		scrollPane.setBorder(new TitledBorder(null, "Historial de Ganadores", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		GroupLayout gl_contentPane = new GroupLayout(contentPane);
		gl_contentPane.setHorizontalGroup(
			gl_contentPane.createParallelGroup(Alignment.TRAILING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addGap(0)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
						.addGroup(gl_contentPane.createSequentialGroup()
							.addComponent(lblElGanadorEs)
							.addGap(18)
							.addComponent(ganador))
						.addGroup(gl_contentPane.createSequentialGroup()
							.addGap(7)
							.addComponent(label)
							.addPreferredGap(ComponentPlacement.UNRELATED)
							.addComponent(label_1, GroupLayout.PREFERRED_SIZE, 128, GroupLayout.PREFERRED_SIZE)
							.addGap(18)
							.addComponent(label_3, GroupLayout.PREFERRED_SIZE, 128, GroupLayout.PREFERRED_SIZE)
							.addGap(10)
							.addComponent(label_2, GroupLayout.PREFERRED_SIZE, 128, GroupLayout.PREFERRED_SIZE)
							.addPreferredGap(ComponentPlacement.UNRELATED)
							.addComponent(label_4, GroupLayout.PREFERRED_SIZE, 128, GroupLayout.PREFERRED_SIZE))
						.addGroup(Alignment.TRAILING, gl_contentPane.createSequentialGroup()
							.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
								.addGroup(gl_contentPane.createSequentialGroup()
									.addComponent(btnVolverAJugar)
									.addGap(18)
									.addComponent(button, GroupLayout.PREFERRED_SIZE, 201, GroupLayout.PREFERRED_SIZE))
								.addGroup(gl_contentPane.createSequentialGroup()
									.addComponent(scrollPane, GroupLayout.DEFAULT_SIZE, 316, Short.MAX_VALUE)
									.addGap(2)))
							.addGap(277)
							.addComponent(label_6))
						.addGroup(Alignment.TRAILING, gl_contentPane.createSequentialGroup()
							.addPreferredGap(ComponentPlacement.RELATED)
							.addComponent(lblEsteJuegoHa))
						.addComponent(lblGraciasPorJugar))
					.addContainerGap())
		);
		gl_contentPane.setVerticalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblElGanadorEs)
						.addComponent(ganador))
					.addGap(18)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
						.addComponent(label_4, GroupLayout.PREFERRED_SIZE, 128, GroupLayout.PREFERRED_SIZE)
						.addComponent(label_3, GroupLayout.PREFERRED_SIZE, 128, GroupLayout.PREFERRED_SIZE)
						.addComponent(label_2, GroupLayout.PREFERRED_SIZE, 128, GroupLayout.PREFERRED_SIZE)
						.addComponent(label)
						.addComponent(label_1, GroupLayout.PREFERRED_SIZE, 128, GroupLayout.PREFERRED_SIZE))
					.addGroup(gl_contentPane.createParallelGroup(Alignment.TRAILING)
						.addGroup(gl_contentPane.createSequentialGroup()
							.addGap(18)
							.addComponent(lblGraciasPorJugar)
							.addGap(18)
							.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
								.addComponent(btnVolverAJugar)
								.addComponent(button))
							.addPreferredGap(ComponentPlacement.UNRELATED)
							.addComponent(scrollPane, GroupLayout.DEFAULT_SIZE, 70, Short.MAX_VALUE)
							.addGap(16))
						.addGroup(gl_contentPane.createSequentialGroup()
							.addPreferredGap(ComponentPlacement.RELATED)
							.addComponent(label_6)
							.addPreferredGap(ComponentPlacement.UNRELATED)))
					.addComponent(lblEsteJuegoHa))
		);
		
		listaGanadores = new JList<String>(listaModeloGanadores);
		listaGanadores.setBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null));
		scrollPane.setViewportView(listaGanadores);
		contentPane.setLayout(gl_contentPane);
		try {
			ganador.setText(controlador.getGanador().getNombre());
		} catch (RemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		mostrarGanadores(controlador);		
	}
	
	public void mostrarGanadores(Controlador controlador)
	{
		ArrayList<String> lista = controlador.getListaGanadores();
		for(String s: lista)
			listaModeloGanadores.addElement(s);
	}
	
	
}
