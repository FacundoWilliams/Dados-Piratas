package vista.consola;
import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.Scanner;

import controlador.Controlador;
import controlador.IVista;
import modelo.IJugador;;

public class VistaConsola implements IVista{
	private Menu menuConfig;
	private Menu menuJugando;
	private Menu menuFin;
	private Controlador controlador;

	public VistaConsola(Controlador controlador) {
		controlador.setVista(this);
		this.controlador = controlador;
		//mostrarConfigurando();
		menuConfig = new MenuConfiguracion(controlador,this);

	}

	/* (non-Javadoc)
	 * @see vista.consola.IVista#mostrarConfigurando()
	 */
	@Override
	public void mostrarConfigurando() {
		menuConfig = new MenuConfiguracion(controlador,this);
		try {
			menuConfig.mostrar();
		} catch (RemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}		
	}

	/* (non-Javadoc)
	 * @see vista.consola.IVista#mostrarJugando()
	 */
	@Override
	public void mostrarJugando() {
		try {
			menuJugando = new MenuJugando(controlador,this);
		} catch (RemoteException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		try {
			menuJugando.mostrar();
		} catch (RemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/* (non-Javadoc)
	 * @see vista.consola.IVista#definirCantMaxDados()
	 */
	public void definirCantMaxDados() {
		Scanner scanner = new Scanner(System.in);
		System.out.println("Ingresar cantidad maxima de dados ==>");
		String max = scanner.nextLine();
		if ( (Integer.valueOf(max)>1) && (Integer.valueOf(max)<11) )
		{
			try {
				controlador.definirCantMaxDados(Integer.valueOf(max));
			} catch (NumberFormatException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IllegalArgumentException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (Exception e) {
				e.printStackTrace();
			}
			scanner.close();
		}
		else
			System.out.println("El valor ingresado no es valido(se mantiene el valor por defecto)");
			mostrarConfigurando();
		}

	/* (non-Javadoc)
	 * @see vista.consola.IVista#definirCantMaxCaras()
	 */
	public void definirCantMaxCaras() {
		Scanner scanner = new Scanner(System.in);
		System.out.println("Ingresar cantidad maxima de caras ==>");
		String max = scanner.nextLine();
		if ( (Integer.valueOf(max)>1) && (Integer.valueOf(max)<21) )
		{
		try {
			controlador.definirCantMaxCaras(Integer.valueOf(max));
		} catch (NumberFormatException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IllegalArgumentException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
		scanner.close();
		}
		else {
			System.out.println("El valor ingresado no es valido(se mantiene el valor por defecto)");
			mostrarConfigurando();
		}
		
	}

	/* (non-Javadoc)
	 * @see vista.consola.IVista#mostrarJugadores()
	 */

	public String mostrarJugadores() {
		String s="";
		ArrayList<IJugador> js;
		try {
			js = controlador.getJugadores();
			for(IJugador j : js)
				s = s + j.getNombre() + ", ";
		} catch (RemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return s;
		
		
	}

	/* (non-Javadoc)
	 * @see vista.consola.IVista#getUltimaProposicion()
	 */

	public String getUltimaProposicion() {
		String s="El jugador ";
		try {
			s = s + controlador.getUltimoJugadorPropuso().getNombre();
			s = s + " propone que hay " + controlador.getUltimaProposicionCant()+
					" dados con el valor de "+controlador.getUltimaProposicionValor();
		} catch (RemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return s;
	}

	/* (non-Javadoc)
	 * @see vista.consola.IVista#desconfiaPierde()
	 */
	@Override
	public void desconfiaPierde() {
		 System.out.println("El oponente no miente, pierdes un dado!");
	}

	/* (non-Javadoc)
	 * @see vista.consola.IVista#desconfiaGana()
	 */
	@Override
	public void desconfiaGana() {
		System.out.println("El oponente miente, pierde un dado!");		
	}

	/* (non-Javadoc)
	 * @see vista.consola.IVista#mostrarFinDelJuego()
	 */
	@Override
	public void mostrarFinDelJuego() {
		try {
			menuFin = new FinDelJuego(controlador,this);
			menuFin.mostrar();
		} catch (RemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/* (non-Javadoc)
	 * @see vista.consola.IVista#mostrarMensaje(java.lang.String)
	 */
	@Override
	public void mostrarMensaje(String mensaje) {
		System.out.println(mensaje);		
	}

	/* (non-Javadoc)
	 * @see vista.consola.IVista#apuestaSeguraGana()
	 */
	@Override
	public void apuestaSeguraGana() {
		System.out.println("Ganas la Apuesta Segura!!");
		System.out.println("Todos los jugadores pierden un dado!");
	}

	/* (non-Javadoc)
	 * @see vista.consola.IVista#apuestaSeguraPierde()
	 */
	@Override
	public void apuestaSeguraPierde() {
		System.out.println("Pierdes la Apuesta Segura!!");
		System.out.println("Pierdes un dado!");
	}

	/* (non-Javadoc)
	 * @see vista.consola.IVista#mostrarTodosLosDados()
	 */
	@Override
	public void mostrarTodosLosDados() {//muestra todos los dados por jugador
		ArrayList<IJugador> jugadores;
		try {
			jugadores = controlador.getJugadores();
			for (IJugador j:jugadores)
				mostrarValoresJugador(j);
		} catch (RemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}		
	}
	
	public void mostrarValoresJugador(IJugador jugador) {
		try {
			String s="Dados del jugador: "+jugador.getNombre()+"\n";
			int[] valores;
			valores = jugador.getValoresDados();
			for (int i=0;i<valores.length;i++)
				s = s + '['+ Integer.toString(valores[i]) + "]  ";			
			System.out.println(s);
		} catch (RemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/* (non-Javadoc)
	 * @see vista.consola.IVista#mostrarInstrucciones()
	 */
	public void mostrarInstrucciones() {
		try {
			System.out.println(controlador.getInstrucciones());
		} catch (RemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Override
	public void iniciar() {
		mostrarConfigurando();
		
	}
}
