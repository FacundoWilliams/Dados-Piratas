package vista.consola;

import java.rmi.RemoteException;
import java.util.Scanner;

import controlador.Controlador;

public class MenuConfiguracion extends Menu {

	public MenuConfiguracion(Controlador controlador, VistaConsola vista) 
	{
		super(controlador, vista);
	}

	@Override
	public void mostrar() 
	{
		System.out.println("$$$ Dados Piratas $$$");
		System.out.println("Menu de configuracion.");
		System.out.println("|1| - Agregar un jugador");
		System.out.println("|2| - Cambiar cantidad maxima de dados (entre 2 y 10)");
		System.out.println("|3| - Cambiar cantidad maxima de caras (entre 2 y 20)");
		System.out.println("|4| - Instrucciones del juego");
		System.out.println("Jugadores conectados: " + vista.mostrarJugadores());
		System.out.println("|0| - Iniciar partida...Suerte!");
		System.out.println("Ingresar opcion ==>");
		Scanner scanner = new Scanner(System.in);
		String op = scanner.nextLine();
		System.out.println("Se ha escogido la opcion [" + op + "]");
		switch (op) {
		case "1":
			System.out.println("Ingresar nombre del jugador ==>");
			String nombre;
			nombre = scanner.nextLine();
			System.out.println(nombre + " se une a la partida!");
			controlador.agregarJugador(nombre);
			break;
		case "2":
			vista.definirCantMaxDados();
			break;
		case "3":
			vista.definirCantMaxCaras();
			break;
		case "0":
			controlador.iniciarPartida();
			break;
		case "4":
			vista.mostrarInstrucciones();
			mostrar();
			break;
		default:
			System.out.println("�Elegir una opcion valida!");
			vista.mostrarConfigurando();
			break;

		}
		scanner.close();
	}

}
